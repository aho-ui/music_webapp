from django.contrib import admin
from .models import *

admin.site.register([
    User,
    Artist,
    Album,
    Song,
    Playlist,
    PlaylistSong,
    ListeningHistory,
    Like,
    Recommendation
])
